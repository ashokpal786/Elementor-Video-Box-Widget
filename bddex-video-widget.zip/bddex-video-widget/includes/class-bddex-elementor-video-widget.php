<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BDDEX_Elementor_Video_Widget extends \Elementor\Widget_Base {
	public function get_name() {
		return 'bddex_video_widget';
	}

	public function get_title() {
		return esc_html__( 'BDDEX Video', 'bddex-video-widget' );
	}

	public function get_icon() {
		return 'eicon-play';
	}

	public function get_categories() {
		return array( 'general' );
	}

	public function get_keywords() {
		return array( 'video', 'youtube', 'hosted', 'hover', 'thumbnail' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_video',
			array(
				'label' => esc_html__( 'Video', 'bddex-video-widget' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'video_source',
			array(
				'label'   => esc_html__( 'Video Source', 'bddex-video-widget' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'youtube',
				'options' => array(
					'youtube' => esc_html__( 'YouTube', 'bddex-video-widget' ),
					'hosted'  => esc_html__( 'Self Hosted', 'bddex-video-widget' ),
				),
			)
		);

		$this->add_control(
			'youtube_url',
			array(
				'label'       => esc_html__( 'YouTube URL', 'bddex-video-widget' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => 'https://www.youtube.com/watch?v=VIDEO_ID',
				'label_block' => true,
				'dynamic'     => array(
					'active'     => true,
					'categories' => array(
						\Elementor\Modules\DynamicTags\Module::POST_META_CATEGORY,
						\Elementor\Modules\DynamicTags\Module::URL_CATEGORY,
					),
				),
				'condition'   => array(
					'video_source' => 'youtube',
				),
			)
		);

		$this->add_control(
			'hosted_video_url',
			array(
				'label'       => esc_html__( 'Self Hosted Video URL', 'bddex-video-widget' ),
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => 'https://example.com/video.mp4',
				'label_block' => true,
				'dynamic'     => array(
					'active'     => true,
					'categories' => array(
						\Elementor\Modules\DynamicTags\Module::POST_META_CATEGORY,
						\Elementor\Modules\DynamicTags\Module::URL_CATEGORY,
					),
				),
				'condition'   => array(
					'video_source' => 'hosted',
				),
			)
		);

		$this->add_control(
			'hosted_video',
			array(
				'label'      => esc_html__( 'Self Hosted Video File', 'bddex-video-widget' ),
				'type'       => \Elementor\Controls_Manager::MEDIA,
				'media_type' => 'video',
				'dynamic'    => array(
					'active'     => true,
					'categories' => array(
						\Elementor\Modules\DynamicTags\Module::MEDIA_CATEGORY,
					),
				),
				'condition'  => array(
					'video_source' => 'hosted',
				),
			)
		);

		$this->add_control(
			'thumbnail',
			array(
				'label'      => esc_html__( 'Video Thumbnail', 'bddex-video-widget' ),
				'type'       => \Elementor\Controls_Manager::MEDIA,
				'media_type' => 'image',
				'dynamic'    => array(
					'active' => true,
				),
			)
		);

		$this->add_control(
			'play_on_hover',
			array(
				'label'        => esc_html__( 'Preview on Hover', 'bddex-video-widget' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'bddex-video-widget' ),
				'label_off'    => esc_html__( 'No', 'bddex-video-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'preview_duration',
			array(
				'label'      => esc_html__( 'Hover Preview Time', 'bddex-video-widget' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 's' ),
				'range'      => array(
					's' => array(
						'min'  => 1,
						'max'  => 20,
						'step' => 1,
					),
				),
				'default'    => array(
					'unit' => 's',
					'size' => 5,
				),
				'condition'  => array(
					'play_on_hover' => 'yes',
				),
			)
		);

		$this->add_control(
			'play_on_click',
			array(
				'label'        => esc_html__( 'Full Video on Click', 'bddex-video-widget' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'bddex-video-widget' ),
				'label_off'    => esc_html__( 'No', 'bddex-video-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'loop_video',
			array(
				'label'        => esc_html__( 'Loop Video', 'bddex-video-widget' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'bddex-video-widget' ),
				'label_off'    => esc_html__( 'No', 'bddex-video-widget' ),
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'no_suggested_videos',
			array(
				'label'        => esc_html__( 'No Suggested Videos', 'bddex-video-widget' ),
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Yes', 'bddex-video-widget' ),
				'label_off'    => esc_html__( 'No', 'bddex-video-widget' ),
				'return_value' => 'yes',
				'default'      => 'yes',
				'condition'    => array(
					'video_source' => 'youtube',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_style',
			array(
				'label' => esc_html__( 'Style', 'bddex-video-widget' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'aspect_ratio',
			array(
				'label'     => esc_html__( 'Aspect Ratio', 'bddex-video-widget' ),
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => '16 / 9',
				'options'   => array(
					'16 / 9' => '16:9',
					'4 / 3'  => '4:3',
					'1 / 1'  => '1:1',
					'9 / 16' => '9:16',
				),
				'selectors' => array(
					'{{WRAPPER}} .bddex-video-widget' => 'aspect-ratio: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'border_radius',
			array(
				'label'      => esc_html__( 'Border Radius', 'bddex-video-widget' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 80,
					),
					'%'  => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bddex-video-widget' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$source   = ! empty( $settings['video_source'] ) ? $settings['video_source'] : 'youtube';
		$thumb    = ! empty( $settings['thumbnail']['url'] ) ? $settings['thumbnail']['url'] : '';
		$video    = $this->get_video_data( $settings, $source );
		$duration = ! empty( $settings['preview_duration']['size'] ) ? absint( $settings['preview_duration']['size'] ) * 1000 : 5000;

		if ( empty( $video['url'] ) ) {
			if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
				echo '<div class="bddex-video-widget bddex-video-widget--empty">' . esc_html__( 'Choose a video URL or file.', 'bddex-video-widget' ) . '</div>';
			}
			return;
		}

		$this->add_render_attribute(
			'wrapper',
			array(
				'class'              => array( 'bddex-video-widget', 'bddex-video-widget--' . $source ),
				'data-video-source'  => esc_attr( $source ),
				'data-video-url'     => esc_url( $video['url'] ),
				'data-play-hover'    => 'yes' === $settings['play_on_hover'] ? 'yes' : 'no',
				'data-play-click'    => 'yes' === $settings['play_on_click'] ? 'yes' : 'no',
				'data-preview-duration' => $duration,
				'data-loop'          => 'yes' === $settings['loop_video'] ? 'yes' : 'no',
				'data-youtube-id'    => esc_attr( $video['youtube_id'] ),
				'data-no-suggested'  => 'yes' === $settings['no_suggested_videos'] ? 'yes' : 'no',
				'role'               => 'button',
				'tabindex'           => '0',
				'aria-label'         => esc_attr__( 'Play video', 'bddex-video-widget' ),
			)
		);
		?>
		<div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
			<?php if ( $thumb ) : ?>
				<img class="bddex-video-widget__thumbnail" src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr__( 'Video thumbnail', 'bddex-video-widget' ); ?>">
			<?php else : ?>
				<div class="bddex-video-widget__placeholder"></div>
			<?php endif; ?>

			<div class="bddex-video-widget__stage" aria-hidden="true"></div>
			<span class="bddex-video-widget__play" aria-hidden="true"></span>
			<button class="bddex-video-widget__stop" type="button" aria-label="<?php echo esc_attr__( 'Stop video', 'bddex-video-widget' ); ?>"></button>
		</div>
		<?php
	}

	private function get_video_data( $settings, $source ) {
		$data = array(
			'url'        => '',
			'youtube_id' => '',
		);

		if ( 'hosted' === $source ) {
			if ( ! empty( $settings['hosted_video_url']['url'] ) ) {
				$data['url'] = $settings['hosted_video_url']['url'];
				return $data;
			}

			$data['url'] = ! empty( $settings['hosted_video']['url'] ) ? $settings['hosted_video']['url'] : '';
			return $data;
		}

		$url = ! empty( $settings['youtube_url'] ) ? trim( $settings['youtube_url'] ) : '';
		if ( ! $url ) {
			return $data;
		}

		$data['youtube_id'] = $this->get_youtube_id( $url );
		$data['url']        = $data['youtube_id'] ? 'https://www.youtube.com/embed/' . $data['youtube_id'] : $url;

		return $data;
	}

	private function get_youtube_id( $url ) {
		$patterns = array(
			'~youtu\.be/([a-zA-Z0-9_-]{6,})~',
			'~youtube\.com/watch\?v=([a-zA-Z0-9_-]{6,})~',
			'~youtube\.com/embed/([a-zA-Z0-9_-]{6,})~',
			'~youtube\.com/shorts/([a-zA-Z0-9_-]{6,})~',
		);

		foreach ( $patterns as $pattern ) {
			if ( preg_match( $pattern, $url, $matches ) ) {
				return $matches[1];
			}
		}

		return '';
	}
}
