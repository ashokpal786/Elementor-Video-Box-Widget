(function () {
	'use strict';

	function youtubeUrl(widget, autoplay, muted) {
		var id = widget.dataset.youtubeId || '';
		var base = widget.dataset.videoUrl || '';
		var params = new URLSearchParams({
			autoplay: autoplay ? '1' : '0',
			mute: muted ? '1' : '0',
			controls: '0',
			playsinline: '1',
			rel: widget.dataset.noSuggested === 'yes' ? '0' : '1',
			modestbranding: '1',
			enablejsapi: '1'
		});

		if (widget.dataset.loop === 'yes') {
			params.set('loop', '1');
			if (id) {
				params.set('playlist', id);
			}
		}

		return base + '?' + params.toString();
	}

	function sendYoutubeCommand(iframe, command) {
		if (!iframe || !iframe.contentWindow) {
			return;
		}

		iframe.contentWindow.postMessage(JSON.stringify({
			event: 'command',
			func: command,
			args: []
		}), '*');
	}

	function ensurePlayer(widget, muted, trigger) {
		var stage = widget.querySelector('.bddex-video-widget__stage');
		var source = widget.dataset.videoSource;

		if (!stage) {
			return null;
		}

		if (stage.firstElementChild) {
			if (source === 'youtube' && muted === false && stage.firstElementChild.src.indexOf('mute=1') !== -1) {
				stage.firstElementChild.src = youtubeUrl(widget, true, false);
			}
			return stage.firstElementChild;
		}

		if (source === 'youtube') {
			var iframe = document.createElement('iframe');
			iframe.src = youtubeUrl(widget, true, muted);
			iframe.title = 'Video player';
			iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
			iframe.allowFullscreen = true;
			iframe.setAttribute('loading', 'eager');
			stage.appendChild(iframe);
			return iframe;
		}

		var video = document.createElement('video');
		video.src = widget.dataset.videoUrl;
		video.autoplay = true;
		video.playsInline = true;
		video.setAttribute('playsinline', '');
		video.controls = false;
		video.loop = widget.dataset.loop === 'yes';
		video.muted = muted;
		if (muted) {
			video.setAttribute('muted', '');
		} else {
			video.removeAttribute('muted');
		}
		video.preload = 'metadata';
		stage.appendChild(video);
		return video;
	}

	function stop(widget) {
		var stage = widget.querySelector('.bddex-video-widget__stage');
		var player = stage ? stage.firstElementChild : null;

		widget.classList.remove('is-playing');
		widget.classList.remove('is-previewing');
		widget.dataset.previewPlaying = 'no';

		if (widget.bddexPreviewTimer) {
			window.clearTimeout(widget.bddexPreviewTimer);
			widget.bddexPreviewTimer = null;
		}

		if (!player) {
			return;
		}

		if (player.tagName === 'VIDEO') {
			player.pause();
			player.currentTime = 0;
			return;
		}

		sendYoutubeCommand(player, 'stopVideo');
		stage.innerHTML = '';
	}

	function stopOtherWidgets(activeWidget) {
		document.querySelectorAll('.bddex-video-widget').forEach(function (widget) {
			if (widget !== activeWidget) {
				stop(widget);
			}
		});
	}

	function play(widget, muted, trigger) {
		if (trigger === 'click') {
			stopOtherWidgets(widget);
		}

		var player = ensurePlayer(widget, muted, trigger);
		widget.classList.add('is-playing');
		widget.classList.remove('is-previewing');
		widget.dataset.previewPlaying = 'no';

		if (widget.bddexPreviewTimer) {
			window.clearTimeout(widget.bddexPreviewTimer);
			widget.bddexPreviewTimer = null;
		}

		if (player && player.tagName === 'VIDEO') {
			player.muted = muted;
			if (muted) {
				player.setAttribute('muted', '');
			} else {
				player.removeAttribute('muted');
			}
			player.play().catch(function () {});
			return;
		}

		if (player && player.tagName === 'IFRAME') {
			window.setTimeout(function () {
				sendYoutubeCommand(player, 'playVideo');
			}, 250);
		}
	}

	function preview(widget) {
		if (widget.classList.contains('is-playing')) {
			return;
		}

		var player = ensurePlayer(widget, true, 'hover');
		var duration = parseInt(widget.dataset.previewDuration || '5000', 10);

		widget.classList.add('is-previewing');
		widget.classList.remove('is-playing');
		widget.dataset.previewPlaying = 'yes';

		if (player && player.tagName === 'VIDEO') {
			player.muted = true;
			player.setAttribute('muted', '');
			player.play().catch(function () {});
		}

		if (player && player.tagName === 'IFRAME') {
			window.setTimeout(function () {
				sendYoutubeCommand(player, 'playVideo');
			}, 250);
		}

		if (widget.bddexPreviewTimer) {
			window.clearTimeout(widget.bddexPreviewTimer);
		}

		widget.bddexPreviewTimer = window.setTimeout(function () {
			if (widget.dataset.previewPlaying === 'yes') {
				stop(widget);
			}
		}, duration);
	}

	function bindWidget(widget) {
		if (widget.dataset.bddexVideoReady === 'yes') {
			return;
		}

		widget.dataset.bddexVideoReady = 'yes';

		widget.addEventListener('mouseenter', function () {
			if (widget.dataset.playHover === 'yes') {
				preview(widget);
			}
		});

		widget.addEventListener('mouseleave', function () {
			if (widget.dataset.previewPlaying === 'yes') {
				stop(widget);
			}
		});

		widget.addEventListener('click', function () {
			if (widget.dataset.playClick === 'yes') {
				play(widget, false, 'click');
			}
		});

		var stopButton = widget.querySelector('.bddex-video-widget__stop');
		if (stopButton) {
			stopButton.addEventListener('click', function (event) {
				event.preventDefault();
				event.stopPropagation();
				stop(widget);
			});
		}

		widget.addEventListener('keydown', function (event) {
			if ((event.key === 'Enter' || event.key === ' ') && widget.dataset.playClick === 'yes') {
				event.preventDefault();
				play(widget, false, 'click');
			}
		});
	}

	function init(scope) {
		(scope || document).querySelectorAll('.bddex-video-widget').forEach(bindWidget);
	}

	document.addEventListener('DOMContentLoaded', function () {
		init(document);
	});

	if (window.elementorFrontend && window.elementorFrontend.hooks) {
		window.elementorFrontend.hooks.addAction('frontend/element_ready/bddex_video_widget.default', function ($scope) {
			init($scope[0]);
		});
	}
})();
