<?php
/**
 * Plugin Name: BDDEX Elementor Video Widget
 * Description: Adds an Elementor video widget for YouTube and self-hosted videos with thumbnail, hover/click playback, loop, and related-video controls.
 * Version: 1.0.8
 * Author: BDDEX
 * Text Domain: bddex-video-widget
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BDDEX_VIDEO_WIDGET_VERSION', '1.0.8' );
define( 'BDDEX_VIDEO_WIDGET_FILE', __FILE__ );
define( 'BDDEX_VIDEO_WIDGET_PATH', plugin_dir_path( __FILE__ ) );
define( 'BDDEX_VIDEO_WIDGET_URL', plugin_dir_url( __FILE__ ) );

final class BDDEX_Elementor_Video_Widget_Plugin {
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	public function init() {
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', array( $this, 'missing_elementor_notice' ) );
			return;
		}

		add_action( 'elementor/frontend/after_enqueue_scripts', array( $this, 'enqueue_frontend_assets' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
	}

	public function missing_elementor_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html__( 'BDDEX Elementor Video Widget requires Elementor to be installed and active.', 'bddex-video-widget' )
		);
	}

	public function enqueue_frontend_assets() {
		wp_enqueue_style(
			'bddex-video-widget',
			BDDEX_VIDEO_WIDGET_URL . 'assets/css/bddex-video-widget.css',
			array(),
			BDDEX_VIDEO_WIDGET_VERSION
		);

		wp_enqueue_script(
			'bddex-video-widget',
			BDDEX_VIDEO_WIDGET_URL . 'assets/js/bddex-video-widget.js',
			array(),
			BDDEX_VIDEO_WIDGET_VERSION,
			true
		);
	}

	public function register_widgets( $widgets_manager ) {
		require_once BDDEX_VIDEO_WIDGET_PATH . 'includes/class-bddex-elementor-video-widget.php';
		$widgets_manager->register( new \BDDEX_Elementor_Video_Widget() );
	}
}

new BDDEX_Elementor_Video_Widget_Plugin();
